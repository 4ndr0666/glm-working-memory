#!/usr/bin/env python3
"""qa_v161.py — post-compile QA battery for paper-2 v1.6.1 (fail-visible)."""
import sys
import pypdf

PDF = "/home/z/my-project/scripts/build-v161/main.pdf"
r = pypdf.PdfReader(PDF)
text = "\n".join((p.extract_text() or "") for p in r.pages)

fails = []

# 1. undefined-reference scan
qq = text.count("??")
print(f"[{'OK' if qq == 0 else 'FAIL'}] ??-scan: {qq} occurrences")
if qq:
    fails.append("??-scan")

# 2. literal anchors byte-verified in PDF text
anchors = {
    "GWM-HEAD 088ef69…": "088ef6962ace7fd26f6c0c8e9efdcfc9d3b6622c",
    "CDP-HEAD 6facbf17…": "6facbf17a8dcf5dad1bdd441b328760b8b49779f",
    "MEDA-HEAD 9fc75309…": "9fc75309b3f29a1068798a26e0e527da87b8f2cf",
    "GWM-MANIFEST 3be548ee…": "3be548ee3109f759142cefff968881df2a7525492e183c0709bcd1c563e62f14",
    "CDP-MANIFEST bccc75a5…": "bccc75a5137689a913d0ce3f4432abdbae23d8dedf49d69c747ab16f5e3bfff1",
    "MEDA-MANIFEST edbfae9d…": "edbfae9d0aeb6857fb930b300f30bbc9f8fd8eb7acf948ed57ca9e9debf35ff3",
    "GWM-BUNDLE 6d224618…": "6d22461863939c5fff7b5297ba129a2008be25a69a50e49a7847f829db55dab2",
    "TAG-FINGERPRINT 888EAEEF…": "888EAEEFF89E8CAFACAF191873DD9742274C7549",
    "E-3 DAG 0dd0cdb9…": "0dd0cdb90549a0def366890ddd326995b735ec590a0734dc068495ab48ab20af",
    "A-1 manifest 5fce9669…": "5fce96691619d6d13630cac3262a9a2d9d40798e660245a416ba5512487298a0",
    "tag-commit d4018e5…": "d4018e5be0f82ca0985c259fbae2ad09fd6241f5",
}
for label, dig in anchors.items():
    hit = dig in text
    print(f"[{'OK' if hit else 'FAIL'}] anchor-in-pdf: {label}")
    if not hit:
        fails.append(label)

# 3. Table-5 value spot-checks (v1.6.1 expected states)
checks = {
    "GWM sessions 22/22": "22/22",
    "CDP root 48/48": "48/48",
    "MEDA manifest 29/29": "29/29",
    "pinchain anchors 13": "13 anchors",
    "A1 admission (gate-clean)": "R2-37 ancestry gate",
}
for label, needle in checks.items():
    hit = needle in text
    print(f"[{'OK' if hit else 'FAIL'}] table5-value: {label} ('{needle}')")
    if not hit:
        fails.append(label)

print(f"\nPAGES: {len(r.pages)} (v1.6 baseline: 27)")
if fails:
    print("QA FAIL-CLOSED:", fails)
    sys.exit(1)
print("QA OK — all anchors byte-verified in PDF text; values match the v1.6.1 emission")
