#!/usr/bin/env python3
"""emit_verification_data_v161.py — D8 build-time verification emitter, v1.6.1.

v1.6.1 maintenance refresh (R2-55 disposition fork, operator-selected):
parameterized from v1.6 by the witness at Task 59 (trace 1a167750ba56e08d):
  - CDP pinned anchor advanced e2f3d86 -> 6facbf17 (the reconciliation commit
    itself reconciled the manifest; origin tip is now the pinned,
    manifest-consistent state — 48/48, carrying the R2-46 articulation pin).
    The v1.6 CDP special case (pinned-commit anchor over a 46/47 origin-tip
    defect) collapses to the plain HEAD == origin/main contract.
  - MEDA-PINCHAIN takes the clean path: A1 re-pinned to 4bc2cfb and A3
    re-pinned to 6facbf17 at maintenance commit 9fc75309b3f2 (Tasks 36/50/56
    queue discharged); no admission gymnastics remain.
  - OUT_DIR -> scripts/build-v161 (v1.6 outputs left pristine).
All v1.6 legs, gates, and fail-closed semantics unchanged:
  R2-37  A1 ancestry gate: drift is admitted iff a1c27468... is an ancestor of
         origin/main AND the build head equals origin/main; any other FAIL
         aborts. Also asserts the historical PIN source a207175 is an
         ancestor (A-3 parameterization gate) and that the signed tag's
         commit is an ancestor of the build head (A-2 signed-region scope).
  R2-49  Satellite loop (CDP, MEDA): rc-checked git, HEAD == origin/main
         asserted (force-push/staleness hole closed), tar digest computed
         IN-PROCESS via hashlib over `git archive --format=tar origin/main`
         bytes (no shell pipe; empty-stream sentinel asserted absent).
  R2-46  CDP root manifest count emitted dynamically (no static prose).
  R2-36  L3 emitted per repository (CDP disclosure record vs GWM substrate).
  A-1    Pre-rename literal anchors emitted and asserted BEFORE the L0/L1
         loops.
  E-3    Deterministic full-DAG SHA-256 log (pinned reduction order).
Fail-closed throughout: any unexpected FAIL aborts with exit 1 and no .tex.
"""
import hashlib
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone

BASE = "/home/z/my-project"
CDP = os.path.join(BASE, "coordinated-disclosure-public")
MEDA = os.path.join(BASE, "4ndr0meda")
GWM = os.path.join(BASE, "glm-working-memory")
OUT_DIR = os.path.join(BASE, "scripts", "build-v161")
PINCHAIN_MD = os.path.join(CDP, "PIN-CHAIN-RECOMPUTATION.md")
A207175 = "a207175"
A1C27468 = "a1c27468db880dd224f879e2330cd3e512c6c66b"
TAG = "witness-anchor-2026-10-20"
EMPTY_SHA = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
# CDP pinned anchor (v1.6.1 refresh): the origin tip itself — the
# reconciliation commit 6facbf1 restored manifest consistency at the tip
# (48/48, R2-46 articulation pin carried). HEAD == origin/main == pinned
# state; the v1.6 special case is collapsed (kept as a constant so the
# CDP-ROOT plumbing and the ancestry assertion remain one parameter).
CDP_PINNED = "6facbf17a8dcf5dad1bdd441b328760b8b49779f"

log = []
results = {}
okmap = {}


def sh(cmd, cwd=None):
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    return r.returncode, r.stdout, r.stderr


def shb(cmd, cwd=None):
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True)
    return r.returncode, r.stdout, r.stderr.decode("utf-8", errors="replace")


def sha_of(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def record(name, value, ok=True):
    results[name] = value
    okmap[name] = ok
    log.append(f"[{'OK' if ok else 'FAIL'}] {name}: {value}")


def fatal(msg):
    print("FATAL:", msg)
    print("\n".join(log))
    sys.exit(1)


# ---------------------------------------------------------------- R2-37 ancestry gate (before everything)
for label, target in (("a1c27468 (A1 baseline)", A1C27468), ("a207175 (PIN source)", A207175)):
    rc, _, err = sh(f"git merge-base --is-ancestor {target} origin/main", cwd=GWM)
    if rc != 0:
        fatal(f"R2-37 ancestry gate: {label} is NOT an ancestor of origin/main: {err}")
    log.append(f"R2-37 ancestry gate: {label} is an ancestor of origin/main")

rc, out, _ = sh("git rev-parse origin/main", cwd=GWM)
build_head = out.strip()
rc, out, _ = sh("git rev-parse HEAD", cwd=GWM)
if out.strip() != build_head:
    fatal(f"R2-37/R2-49: local HEAD {out.strip()[:12]} != origin/main {build_head[:12]} (parity gate)")
log.append(f"R2-37/R2-49: HEAD == origin/main == {build_head[:12]} (build pin)")

rc, out, err = sh(f"git rev-parse {TAG}^{{commit}}", cwd=GWM)
if rc != 0:
    fatal(f"A-2: tag commit not resolvable: {err}")
tag_commit = out.strip()
rc, _, err = sh(f"git merge-base --is-ancestor {tag_commit} origin/main", cwd=GWM)
if rc != 0:
    fatal(f"A-2: signed tag {TAG} is not an ancestor of the build head (signed-region scope violated)")
record("TAG-COMMIT", tag_commit)
log.append(f"A-2: signed region scoped — tag {TAG} ({tag_commit[:12]}) is an ancestor of the build head; "
           "the signature covers the release anchor commit, build heads are covered transitively by ancestry + push chain")

# ---------------------------------------------------------------- A-1 pre-rename literal anchors (before L0/L1)
rc, old_manifest_bytes, err = shb(f"git show {A207175}:sessions/MANIFEST.sha256", cwd=GWM)
if rc != 0:
    fatal(f"a207175:sessions/MANIFEST.sha256 not retrievable: {err}")
record("A207-MANIFEST-DIGEST", sha_of(old_manifest_bytes))

rc, out, _ = sh(f"git rev-parse '{A207175}^{{tree}}'", cwd=GWM)
if rc != 0:
    fatal(f"cannot resolve tree of {A207175}")
record("A207-TREE", out.strip())

rc, tar_bytes, err = shb(f"git archive --format=tar {A207175}", cwd=GWM)
if rc != 0 or not tar_bytes:
    fatal(f"A-1 tar-snapshot of {A207175} failed: {err}")
dg = sha_of(tar_bytes)
if dg == EMPTY_SHA:
    fatal("A-1: empty-stream sentinel recorded as tar digest")
record("A207-TAR-DIGEST", dg)
log.append(f"A-1 pre-rename anchors asserted before per-file loops: manifest {results['A207-MANIFEST-DIGEST'][:12]}…, "
           f"tree {results['A207-TREE'][:12]}… (SHA-1, substrate-internal), tar {results['A207-TAR-DIGEST'][:12]}…")

# ---------------------------------------------------------------- L1 (unchanged from v1.5)
l1_ok = l1_total = 0
l1_fails = []
for line in old_manifest_bytes.decode().splitlines():
    line = line.strip()
    if not line or " " not in line:
        continue
    dg, path = line.split(None, 1)
    l1_total += 1
    rc2, content, _ = shb(f"git show {A207175}:'{path.strip()}'", cwd=GWM)
    if rc2 == 0 and sha_of(content) == dg.strip():
        l1_ok += 1
    else:
        l1_fails.append(path.strip())
record("L1", f"{l1_ok}/{l1_total}", ok=(not l1_fails))
if l1_fails:
    log.append("L1 FAILS: " + ", ".join(l1_fails))

# ---------------------------------------------------------------- L3 per repository (R2-36)
for label, repo, rel in (("L3-CDP", CDP, "sessions"), ("L3-GWM", GWM, "sessions")):
    rc, out, _ = sh(f"sha256sum -c {rel}/MANIFEST.sha256", cwd=repo)
    l3_ok = out.count(": OK")
    l3_total = l3_ok + out.count(": FAILED")
    record(label, f"{l3_ok}/{l3_total}", ok=(l3_ok == l3_total and l3_total > 0))

# ---------------------------------------------------------------- L0 (unchanged)
rc, md, _ = sh(f"cat {PINCHAIN_MD}")
md = md if rc == 0 else open(PINCHAIN_MD, encoding="utf-8").read()
sec = re.search(r"## Rename map.*?## ", md, re.S).group(0)
l0_ok = l0_total = 0
l0_fails = []
for m in re.finditer(r"\|\s*`(evidence/[^`]+)`\s*\|\s*`(evidence/[^`]+)`\s*\|\s*`([0-9a-f]{64})`\s*\|", sec):
    old, new, dg = m.group(1), m.group(2), m.group(3)
    l0_total += 1
    rc2, oldb, _ = shb(f"git show {A207175}:'{old}'", cwd=GWM)
    newp = os.path.join(CDP, new)
    if rc2 != 0 or not os.path.exists(newp):
        l0_fails.append(f"{old} (missing)")
        continue
    if sha_of(oldb) == sha_of(open(newp, "rb").read()) == dg:
        l0_ok += 1
    else:
        l0_fails.append(old)
record("L0", f"{l0_ok}/{l0_total}", ok=(not l0_fails))
if l0_fails:
    log.append("L0 FAILS: " + ", ".join(l0_fails))

# ---------------------------------------------------------------- L5 (unchanged)
caps = sorted(
    os.path.join(CDP, "evidence", f)
    for f in os.listdir(os.path.join(CDP, "evidence"))
    if re.match(r"F003-capture-00\d\.pdf", f)
)
heights = []
for p in caps:
    try:
        import pypdf
        r = pypdf.PdfReader(p)
        heights.append(round(float(r.pages[0].mediabox.height), 1))
    except Exception as e:  # noqa: BLE001
        log.append(f"L5 read error {os.path.basename(p)}: {e}")
        heights.append(0.0)
l5_mono = all(a < b for a, b in zip(heights, heights[1:])) and len(heights) == 6
record("L5", f"{heights}", ok=l5_mono)

# ---------------------------------------------------------------- manifests (R2-46: counts dynamic)
# CDP-ROOT runs against the PINNED COMMIT via git plumbing: the origin tip
# carries the manifest reconciliation defect (see R2-49 block); the pinned
# state e2f3d86 is the anchored, manifest-consistent state. Per-line:
# sha256(git show <pinned>:<path>) == recorded digest; count + digest emitted.
rc, pinned_manifest, _ = shb(f"git show {CDP_PINNED}:MANIFEST.sha256", cwd=CDP)
if rc != 0:
    fatal("cannot read CDP pinned manifest")
cdp_root_ok = cdp_root_total = 0
for ln in pinned_manifest.decode().splitlines():
    parts = ln.split(None, 1)
    if len(parts) != 2:
        continue
    dg, path = parts[0], parts[1].strip()
    cdp_root_total += 1
    rc2, content, _ = shb(f"git show {CDP_PINNED}:'{path}'", cwd=CDP)
    if rc2 == 0 and sha_of(content) == dg:
        cdp_root_ok += 1
record("CDP-ROOT", f"{cdp_root_ok}/{cdp_root_total}",
       ok=(cdp_root_ok == cdp_root_total and cdp_root_total > 0))
log.append(f"CDP-ROOT evaluated at pinned commit {CDP_PINNED[:12]} == origin/main (reconciled tip; v1.6.1 refresh)")

rc, out, _ = sh("sha256sum -c sessions/MANIFEST.sha256", cwd=GWM)
gwm_ok = out.count(": OK")
gwm_total = gwm_ok + out.count(": FAILED")
record("GWM-SESSIONS", f"{gwm_ok}/{gwm_total}", ok=(gwm_ok == gwm_total and gwm_total > 0))

rc, out, err = sh("python3 tools/manifest.py verify", cwd=MEDA)
m = re.search(r"(\d+)/(\d+) pinned files match", out)
if not (rc == 0 and m):
    fatal(f"4ndr0meda manifest verify failed: {out} {err}")
record("MEDA-MANIFEST", f"{m.group(1)}/{m.group(2)}")

# ---------------------------------------------------------------- MEDA pinchain under the R2-37 ancestry gate
rc, out, err = sh("python3 tools/pinchain.py verify --local", cwd=MEDA)
pin_ok = len(re.findall(r"^OK\s+", out, re.M))
pin_fail = len(re.findall(r"^FAIL\s+", out, re.M))
pin_unreach = len(re.findall(r"^UNREACHABLE\s+", out, re.M))
failed_anchors = re.findall(r"^FAIL\s+(A\d+)", out, re.M)
total_anchors = pin_ok + pin_fail + pin_unreach
if pin_fail == 0 and pin_unreach == 0:
    record("MEDA-PINCHAIN", f"{pin_ok} OK, {total_anchors} anchors, 0 FAIL", ok=True)
elif set(failed_anchors) <= {"A1", "A3"}:
    # A1 drift admitted ONLY under the already-asserted GWM ancestry condition.
    # A3 (CDP HEAD frozen pin) drift admitted under the R2-37-shape CDP
    # ancestry condition: the pinned A3 commit e2f3d86 must be an ancestor of
    # CDP origin/main (re-asserted here, cheap). Same defect class, same gate
    # shape; MEDA's PIN-CHAIN re-pin rides the next maintenance round.
    rc, _, err = sh(f"git merge-base --is-ancestor {CDP_PINNED} origin/main", cwd=CDP)
    if rc != 0:
        fatal(f"A3 admission failed: CDP pinned anchor not an ancestor of origin/main: {err}")
    admit = []
    if "A1" in failed_anchors:
        admit.append(f"A1 admitted by the R2-37 ancestry gate (a1c27468 ancestor-of origin/main, build head == origin/main == {build_head[:12]})")
    if "A3" in failed_anchors:
        admit.append(f"A3 admitted by the R2-37-shape CDP ancestry gate (e2f3d86 ancestor-of CDP origin/main; re-pin queued, new witness catch registered)")
    record("MEDA-PINCHAIN",
           f"{pin_ok} OK, {'; '.join(admit)}; {total_anchors} anchors", ok=True)
    log.append("R2-37/R2-37-shape: " + "; ".join(admit) + " — the unconditional allowlist class is closed")
else:
    record("MEDA-PINCHAIN", f"{pin_ok} OK, {pin_fail} FAIL ({failed_anchors}), {pin_unreach} unreachable", ok=False)

# ---------------------------------------------------------------- R2-49 satellite loop (CDP, MEDA)
# v1.6.1: both satellites hold the plain contract. (v1.6 anchored CDP at a
# pinned commit because the then-origin-tip e96624d carried a 46/47 manifest
# defect; the reconciliation commit 6facbf1 resolved it — see docstring.)
for label, repo in (("CDP", CDP), ("MEDA", MEDA)):
    rc, _, err = sh("git fetch origin", cwd=repo)
    if rc != 0:
        fatal(f"R2-49: {label} origin fetch failed (staleness fail-closed): {err}")
    rc, out, _ = sh("git rev-parse origin/main", cwd=repo)
    if rc != 0:
        fatal(f"R2-49: {label} origin/main unresolvable")
    origin = out.strip()
    # v1.6.1: plain HEAD == origin/main contract for BOTH satellites — the
    # CDP pinned-commit special case existed only for the v1.6-era 46/47
    # origin-tip defect, which the reconciliation commit 6facbf1 resolved.
    rc, out, _ = sh("git rev-parse HEAD", cwd=repo)
    if rc != 0:
        fatal(f"R2-49: {label} HEAD unresolvable")
    head = out.strip()
    if head != origin:
        fatal(f"R2-49: {label} HEAD {head[:12]} != origin/main {origin[:12]}")
    if label == "CDP" and head != CDP_PINNED:
        fatal(f"v1.6.1 parameterization gate: CDP HEAD {head[:12]} != pinned anchor {CDP_PINNED[:12]} (re-run only at the pinned tip)")
    anchor_commit = head
    anchor_note = "HEAD == origin/main == pinned anchor"
    log.append(f"R2-49: {label} anchored at {anchor_commit[:12]} ({anchor_note}), tar-digest computed in-process")
    rc, tarb, err = shb(f"git archive --format=tar {anchor_commit}", cwd=repo)
    if rc != 0 or not tarb:
        fatal(f"R2-49: {label} git archive failed: {err}")
    dgs = sha_of(tarb)
    if dgs == EMPTY_SHA:
        fatal(f"R2-49: {label} empty-stream sentinel recorded as tar digest")
    record(f"{label}-HEAD", anchor_commit)
    record(f"{label}-TAR-DIGEST", dgs)
    log.append(f"R2-49: {label} anchored at {anchor_commit[:12]} ({anchor_note}), tar-digest {dgs[:12]}… (in-process hashlib, rc-checked)")

# ---------------------------------------------------------------- literal manifest digests (R2-1 anchor-exact form)
rc, out, _ = sh("git show origin/main:sessions/MANIFEST.sha256 | sha256sum", cwd=GWM)
if rc != 0:
    fatal("cannot hash substrate session manifest at origin/main")
record("GWM-MANIFEST-DIGEST", out.split()[0])

rc, out, _ = sh("sha256sum MANIFEST.sha256", cwd=CDP)
if rc != 0:
    fatal("cannot hash CDP root manifest")
record("CDP-MANIFEST-DIGEST", out.split()[0])

rc, out, _ = sh("sha256sum MANIFEST.sha256", cwd=MEDA)
if rc != 0:
    fatal("cannot hash 4ndr0meda root manifest")
record("MEDA-MANIFEST-DIGEST", out.split()[0])

# ---------------------------------------------------------------- GWM head/tree/tar anchors (R2-25, in-process)
rc, out, _ = sh("git rev-parse 'origin/main^{tree}'", cwd=GWM)
if rc != 0:
    fatal("cannot resolve tree of origin/main")
record("GWM-TREE", out.strip())

rc, tarb, err = shb("git archive --format=tar origin/main", cwd=GWM)
if rc != 0 or not tarb:
    fatal(f"GWM tar-snapshot anchor failed: {err}")
dgs = sha_of(tarb)
if dgs == EMPTY_SHA:
    fatal("GWM: empty-stream sentinel recorded as tar digest")
record("GWM-TAR-DIGEST", dgs)

rc, out, err = sh(f"git verify-tag --raw {TAG}", cwd=GWM)
mfp = re.search(r"VALIDSIG\s+([0-9A-Fa-f]{40})", out + err)
if rc != 0 or not mfp:
    fatal(f"signed-tag fingerprint not resolvable: {out} {err}")
record("TAG-FINGERPRINT", mfp.group(1).upper())

# ---------------------------------------------------------------- R2-20 bundle anchor
head7 = build_head[:7]
bundle_path = os.path.join(OUT_DIR, f"gwm-lineage-full-{head7}.bundle")
os.makedirs(OUT_DIR, exist_ok=True)
rc, out, err = sh(f"git bundle create '{bundle_path}' origin/main", cwd=GWM)
if rc != 0:
    fatal(f"full-lineage bundle creation failed: {out} {err}")
with open(bundle_path, "rb") as f:
    bdata = f.read()
if not bdata.startswith(b"# v"):
    fatal("bundle header sanity check failed")
record("GWM-BUNDLE-DIGEST", sha_of(bdata))
record("GWM-BUNDLE-BYTES", str(len(bdata)))

# ---------------------------------------------------------------- E-3 deterministic full-DAG SHA-256 log
dag_rows = []
for c in sorted(subprocess.run(["git", "-C", GWM, "rev-list", "--all", "--", "sessions/"],
                               capture_output=True).stdout.decode().split()):
    for line in subprocess.run(["git", "-C", GWM, "ls-tree", "-r", c, "--", "sessions/"],
                               capture_output=True).stdout.decode().splitlines():
        meta, path = line.split("\t", 1)
        oid = meta.split()[2]
        p = subprocess.run(["git", "-C", GWM, "cat-file", "blob", oid], capture_output=True)
        if p.returncode != 0:
            fatal(f"E-3: cat-file {oid} failed")
        dag_rows.append({"commit": c, "path": path, "sha256": hashlib.sha256(p.stdout).hexdigest()})
dag_rows.sort(key=lambda r: (r["commit"], r["path"], r["sha256"]))  # pinned reduction order
serialization = "".join(f"{r['commit']} {r['path']} {r['sha256']}\n" for r in dag_rows)
record("GWM-DAG-DIGEST", sha_of(serialization.encode()))
record("GWM-DAG-PAIRS", str(len(dag_rows)))
log.append(f"E-3: deterministic full-DAG SHA-256 log emitted — {len(dag_rows)} (commit, path, blob-sha256) rows, "
           f"chain digest {results['GWM-DAG-DIGEST'][:12]}… (pinned reduction order: sorted serialization)")

# ---------------------------------------------------------------- GATE-D walk stats (R2-53 prose numbers, D8-emitted)
commits_touched = subprocess.run(["git", "-C", GWM, "rev-list", "--all", "--", "sessions/"],
                                 capture_output=True).stdout.decode().split()
pair_set = set()
for c in commits_touched:
    for line in subprocess.run(["git", "-C", GWM, "ls-tree", "-r", c, "--", "sessions/"],
                               capture_output=True).stdout.decode().splitlines():
        meta, path = line.split("\t", 1)
        pair_set.add((path, meta.split()[2]))
allow_path = os.path.join(OUT_DIR, "gate-d-allowlist-v1.json")
precon = len(json.load(open(allow_path, encoding="utf-8"))) if os.path.exists(allow_path) else 0
record("GATED-COMMITS", str(len(commits_touched)))
record("GATED-PAIRS", str(len(pair_set)))
record("GATED-PRECON", str(precon))
log.append(f"GATE-D stats: {len(commits_touched)} commits, {len(pair_set)} unique (path, blob) pairs, "
           f"{precon} pre-convention allowlist entries (adjudication record rides the build receipt)")

# ---------------------------------------------------------------- gate + emit
unexpected = [k for k, ok in okmap.items() if not ok]
if unexpected:
    print("FAIL-CLOSED: unexpected verification failures:", unexpected)
    print("\n".join(log))
    sys.exit(1)

now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
date_today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

tex = f"""% AUTO-GENERATED by scripts/emit_verification_data_v16.py at {now}
% Amendment D8 (Task 20 exam): the paper's verification numbers are emitted
% at build time by the verification scripts — never hand-typed. Re-run the
% emitter instead of editing this file. Fail-closed build: an unexpected
% verification failure aborts the paper build.
\\newcommand{{\\vverifydate}}{{{date_today}}}
\\newcommand{{\\vlone}}{{{results['L1']}}}
\\newcommand{{\\vlthreecdp}}{{{results['L3-CDP']}}}
\\newcommand{{\\vlthreegwm}}{{{results['L3-GWM']}}}
\\newcommand{{\\vlzero}}{{{results['L0']}}}
\\newcommand{{\\vlfive}}{{{results['L5']}}}
\\newcommand{{\\vcdproot}}{{{results['CDP-ROOT']}}}
\\newcommand{{\\vgwmsessions}}{{{results['GWM-SESSIONS']}}}
\\newcommand{{\\vmedamanifest}}{{{results['MEDA-MANIFEST']}}}
\\newcommand{{\\vmedapin}}{{{results['MEDA-PINCHAIN']}}}
% R2-1 literal out-of-band anchors (machine-emitted; see docstring)
\\newcommand{{\\vcdpmanifestdigest}}{{{results['CDP-MANIFEST-DIGEST']}}}
\\newcommand{{\\vgwmmanifestdigest}}{{{results['GWM-MANIFEST-DIGEST']}}}
\\newcommand{{\\vmedamanifestdigest}}{{{results['MEDA-MANIFEST-DIGEST']}}}
\\newcommand{{\\vgwmhead}}{{{build_head}}}
\\newcommand{{\\vtagfp}}{{{results['TAG-FINGERPRINT']}}}
\\newcommand{{\\vtagcommit}}{{{results['TAG-COMMIT']}}}
% R2-20 full-lineage bundle anchor (round-2 Surface D fix)
\\newcommand{{\\vgwmbundledigest}}{{{results['GWM-BUNDLE-DIGEST']}}}
\\newcommand{{\\vgwmbundlebytes}}{{{results['GWM-BUNDLE-BYTES']}}}
% R2-25 deterministic anchors (round-3 Surface B fix)
\\newcommand{{\\vgwmtardigest}}{{{results['GWM-TAR-DIGEST']}}}
\\newcommand{{\\vgwmtree}}{{{results['GWM-TREE']}}}
% A-1 pre-rename literal anchors (tier-3 battery, Round-5.1)
\\newcommand{{\\vpreremanifest}}{{{results['A207-MANIFEST-DIGEST']}}}
\\newcommand{{\\vpreretree}}{{{results['A207-TREE']}}}
\\newcommand{{\\vpreretar}}{{{results['A207-TAR-DIGEST']}}}
% R2-38 satellite anchors (HEAD == origin/main asserted, in-process hashlib)
\\newcommand{{\\vcdphead}}{{{results['CDP-HEAD']}}}
\\newcommand{{\\vcdptardigest}}{{{results['CDP-TAR-DIGEST']}}}
\\newcommand{{\\vmedahead}}{{{results['MEDA-HEAD']}}}
\\newcommand{{\\vmedatardigest}}{{{results['MEDA-TAR-DIGEST']}}}
% E-3 deterministic full-DAG SHA-256 log
\\newcommand{{\\vgwmdagdigest}}{{{results['GWM-DAG-DIGEST']}}}
\\newcommand{{\\vgwmdagpairs}}{{{results['GWM-DAG-PAIRS']}}}
% GATE-D walk stats (R2-53 prose numbers; allowlist adjudication rides the receipt)
\\newcommand{{\\vgatedcommits}}{{{results['GATED-COMMITS']}}}
\\newcommand{{\\vgatedpairs}}{{{results['GATED-PAIRS']}}}
\\newcommand{{\\vgatedprecon}}{{{results['GATED-PRECON']}}}
"""

with open(os.path.join(OUT_DIR, "verification-data.tex"), "w", encoding="utf-8") as f:
    f.write(tex)
with open(os.path.join(OUT_DIR, "emitter-build-log.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(log) + "\n")

print("\n".join(log))
print("WROTE", os.path.join(OUT_DIR, "verification-data.tex"))
